// write a C program to input marks of five subjects (Physics, Chemistry, Biology, Mathematics, and Computer). Calculate percentage

#include<stdio.h>

int main() {
    float s1,s2,s3,s4,s5;
    printf("Enter marks of Physics, Chemistry, Biology, Math , ICT: ");
    scanf("%f%f%f%f%f",&s1,&s2,&s3,&s4,&s5);

    float avg = (s1+s2+s3+s4+s5) / 5;
    printf("Your Average Score: %.1f\n",avg);
    if (avg>=90 && avg<= 100) {
        printf("Your Grade is A\n");}
    else if (avg>=80 && avg<= 89) {
        printf("Your Grade is B\n"); }
    else if (avg>=70 && avg<= 79) {
        printf("Your Grade is C\n"); }
    else if (avg>=60 && avg<= 69) {
        printf("Your Grade is D\n"); }
    else if (avg>=40 && avg<= 49) {
        printf("Your Grade is E\n"); }
    else if (avg<40) {
        printf("Your Grade is F\n"); }

}