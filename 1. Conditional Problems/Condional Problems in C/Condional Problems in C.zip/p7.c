// write a C program to input any alphabet and check whether it is vowel or consonant.
#include<stdio.h>
#include<ctype.h>

int main()
{
    char ch;
    printf("Enter your character: ");
    scanf("%c", &ch);
    ch = towlower(ch);


    if (ch == 'a' || ch == 'o' || ch == 'e' || ch == 'i' || ch == 'u') {
        printf("%c is a Vowel",ch);

    }
    else {
        printf("%c is a Consonant",ch);
    }
}